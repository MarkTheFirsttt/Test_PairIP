package com.android.pairipfix;

import android.content.pm.PackageInstaller;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class mainHook implements IXposedHookLoadPackage {
    private static final String PLAY_STORE_PACKAGE = "com.android.vending";
    private static final int PACKAGE_SOURCE_STORE = resolvePackageSourceStore();


    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (lpparam.packageName == null || lpparam.classLoader == null) {
            return;
        }

        hookInstallerChecks(lpparam);
        hookPairipChecks(lpparam);
    }

    private void hookInstallerChecks(final XC_LoadPackage.LoadPackageParam lpparam) {
        hookIfPresent(
                "android.app.ApplicationPackageManager",
                null,
                "getInstallerPackageName",
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam params) {
                        if (isOwnPackage(lpparam, params.args[0])) {
                            params.setResult(PLAY_STORE_PACKAGE);
                        }
                    }
                }
        );

        hookIfPresent(
                "android.app.ApplicationPackageManager",
                null,
                "getInstallSourceInfo",
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam params) {
                        if (!isOwnPackage(lpparam, params.args[0])) {
                            return;
                        }

                        Object result = params.getResult();
                        if (result != null) {
                            spoofInstallSourceInfo(result);
                        }
                    }
                }
        );

        hookIfPresent(
                "android.content.pm.InstallSourceInfo",
                null,
                "getInstallingPackageName",
                XC_MethodReplacement.returnConstant(PLAY_STORE_PACKAGE)
        );

        hookIfPresent(
                "android.content.pm.InstallSourceInfo",
                null,
                "getInitiatingPackageName",
                XC_MethodReplacement.returnConstant(PLAY_STORE_PACKAGE)
        );

        hookIfPresent(
                "android.content.pm.InstallSourceInfo",
                null,
                "getOriginatingPackageName",
                XC_MethodReplacement.returnConstant(PLAY_STORE_PACKAGE)
        );

        hookIfPresent(
                "android.content.pm.InstallSourceInfo",
                null,
                "getPackageSource",
                XC_MethodReplacement.returnConstant(PACKAGE_SOURCE_STORE)
        );
    }

    private void hookPairipChecks(final XC_LoadPackage.LoadPackageParam lpparam) {
        boolean hooked = false;

        hooked |= hookIfPresent(
                "com.pairip.licensecheck.ResponseValidator",
                lpparam.classLoader,
                "validateResponse",
                Bundle.class,
                String.class,
                XC_MethodReplacement.DO_NOTHING
        );
        hooked |= hookIfPresent(
                "com.pairip.licensecheck.LicenseClient",
                lpparam.classLoader,
                "processResponse",
                int.class,
                Bundle.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam params) {
                        params.args[0] = 0;
                    }
                }
        );

        hooked |= hookIfPresent(
                "com.pairip.licensecheck3.ResponseValidator",
                lpparam.classLoader,
                "validateResponse",
                Bundle.class,
                String.class,
                XC_MethodReplacement.DO_NOTHING
        );
        hooked |= hookIfPresent(
                "com.pairip.licensecheck3.LicenseClientV3",
                lpparam.classLoader,
                "processResponse",
                int.class,
                Bundle.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam params) {
                        params.args[0] = 0;
                    }
                }
        );

        if (!hooked) {
            XposedBridge.log("pairipfix: no Pairip classes found in " + lpparam.packageName);
        }
    }

    private boolean isOwnPackage(XC_LoadPackage.LoadPackageParam lpparam, Object packageNameArg) {
        return packageNameArg instanceof String && lpparam.packageName.equals(packageNameArg);
    }

    private void spoofInstallSourceInfo(Object installSourceInfo) {
        setObjectFieldIfPresent(installSourceInfo, "mInstallingPackageName", PLAY_STORE_PACKAGE);
        setObjectFieldIfPresent(installSourceInfo, "mInitiatingPackageName", PLAY_STORE_PACKAGE);
        setObjectFieldIfPresent(installSourceInfo, "mOriginatingPackageName", PLAY_STORE_PACKAGE);
        setIntFieldIfPresent(installSourceInfo, "mPackageSource", PACKAGE_SOURCE_STORE);
    }

    private void setObjectFieldIfPresent(Object target, String fieldName, Object value) {
        try {
            XposedHelpers.setObjectField(target, fieldName, value);
        } catch (Throwable ignored) {
        }
    }

    private void setIntFieldIfPresent(Object target, String fieldName, int value) {
        try {
            XposedHelpers.setIntField(target, fieldName, value);
        } catch (Throwable ignored) {
        }
    }

    private boolean hookIfPresent(String className, ClassLoader classLoader, String methodName, Object... parameterTypesAndCallback) {
        try {
            XposedHelpers.findAndHookMethod(className, classLoader, methodName, parameterTypesAndCallback);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static int resolvePackageSourceStore() {
        try {
            return XposedHelpers.getStaticIntField(PackageInstaller.class, "PACKAGE_SOURCE_STORE");
        } catch (Throwable ignored) {
            return 1;
        }
    }
}
